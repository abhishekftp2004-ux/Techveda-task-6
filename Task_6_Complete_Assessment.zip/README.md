# Task 6 — List and Dictionary Comprehensions

## Description
Use list and dictionary comprehensions to create collections efficiently from existing data.

## Objective
Learn concise Python techniques commonly used in data preprocessing.

## Included
- Multiple list comprehension examples
- Multiple dictionary comprehension examples
- Filtering and transformation
- Conditional expressions
- Nested list comprehension
- Student marks and grade classification
- Product price transformation and filtering
- Traditional loop comparison
- Practical student data processing
- Interview questions and answers

## Files
- Task_6_Complete_Assessment.ipynb
- Task_6_Complete_Assessment.py
- student_marks.csv
- product_dataset.csv
